export default async function run({ client, guild, channel, user, message }) {
    if (!guild) {
        return {
            reply: "Mình không tìm thấy thông tin máy chủ hiện tại bạn ơi ~ 🫧"
        };
    }
    
    // Lấy số lượng thành viên an toàn và nhanh chóng từ cache hoặc fetch có timeout
    let memberCount = guild.memberCount;
    if (!memberCount && guild.members) {
        await guild.members.fetch({ time: 5000 }).catch(() => guild.members.cache);
        memberCount = guild.members.cache.size;
    }

    return {
        reply: `Máy chủ **${guild.name}** hiện tại có tổng cộng **${memberCount || 'không xác định'}** thành viên đang tham gia đó bạn nhé ~ ✨🫧`,
        data: { memberCount }
    };
}