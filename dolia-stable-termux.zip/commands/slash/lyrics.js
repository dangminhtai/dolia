import { t as tr } from '../../services/i18nService.js';
import { SlashCommandBuilder, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } from 'discord.js';
import GeminiLyrics from '../../class/GeminiLyrics.js';
import { sendSafeMessage } from '../../utils/messageHelper.js';
import { t } from '../../services/i18nService.js';

export default {
    data: new SlashCommandBuilder()
        .setName('lyrics')
        .setDescription(tr('commands.lyrics.setdescription_tim_kiem_loi_bai_hat_bang_dolia')),

    async execute(interaction) {
        const modal = new ModalBuilder()
            .setCustomId('lyrics_modal')
            .setTitle(t('general.lyrics.modal_title'));

        const queryInput = new TextInputBuilder()
            .setCustomId('lyrics_query_input')
            .setLabel(t('general.lyrics.input_label'))
            .setPlaceholder(t('general.lyrics.input_placeholder'))
            .setStyle(TextInputStyle.Paragraph) // Sử dụng Paragraph để nhập được nhiều dòng
            .setRequired(true)
            .setMinLength(5)
            .setMaxLength(1000);

        const firstActionRow = new ActionRowBuilder().addComponents(queryInput);
        modal.addComponents(firstActionRow);

        await interaction.showModal(modal);
    }
};
