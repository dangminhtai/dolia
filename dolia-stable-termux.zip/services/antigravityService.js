import { t as tr } from './i18nService.js';
import antigravityKeyManager from '../class/antigravityKeyManager.js';
import Logger from '../class/Logger.js';
import geminiModelService from './geminiModelService.js';
import { loadAgentPrompt } from '../helpers/promptHelper.js';
import SkillHelper from '../helpers/skillHelper.js';
import { getAgentSession, updateAgentSession } from '../helpers/chatHelper.js';

export class AntigravityService {
    /**
     * Ủy quyền cho Antigravity Agent trên Google Cloud Sandbox phát triển (Command hoặc Script)
     * @param {Object} options
     * @param {string} options.prompt - Yêu cầu từ người dùng
     * @param {string} [options.mode='command'] - 'command' (Slash command) hoặc 'script' (Dynamic Inspect/Modify Script)
     * @param {string} [options.featureName] - Tên định danh (slug)
     * @param {Function} [options.onProgress] - Callback cập nhật trạng thái tiến trình
     * @param {Object} [options.context] - Ngữ cảnh Discord { client, guild, channel, user, message }
     * @param {Object} [options.lastScript] - Script cũ nếu là Chained Script Modification
     */
    static async develop({ prompt, mode = 'command', featureName = null, onProgress = null, context = null, lastScript = null }) {
        const isScript = mode === 'script';
        const safeSlug = (featureName || prompt.split(' ')[0])
            .toLowerCase()
            .trim()
            .replace(/đ/g, 'd')
            .replace(/[^a-z0-9_-]/g, '_')
            .replace(/_+/g, '_')
            .substring(0, 32);

        // Ưu tiên flash-lite cho Antigravity Cloud: nhanh hơn, quota rộng hơn, giữ render Discord mượt
        const activeModel = await geminiModelService.getActiveModel('flash-lite', 'agent');
        Logger.info(tr('logs.antigravityservice.info_antigravity_khoi_chay_antigravity_agent_cloud_sandbox', { mode: mode, activeModel: activeModel }));

        // Đọc prompt tùy biến từ config/prompt/agent/AgentInstruction.md và nhúng Skills chuẩn Google Custom Agents
        const baseInstruction = loadAgentPrompt('AgentInstruction.md', {
            '{{safeSlug}}': safeSlug
        });
        const systemInstruction = SkillHelper.enhanceInstructionWithSkills(baseInstruction, prompt);

        let promptInstruction = '';
        if (isScript) {
            if (lastScript && lastScript.code) {
                promptInstruction = `${systemInstruction}\n\n[CHẾ ĐỘ 1: MODIFY SCRIPT - KẾ THỪA MÃ NGUỒN CŨ TRONG WORKSPACE]:\nBạn đang tiếp tục phiên làm việc trong môi trường (workspace) của kênh này.\n\n[MÃ NGUỒN CŨ ĐÃ HOẠT ĐỘNG THÀNH CÔNG TRƯỚC ĐÓ]:\n\`\`\`javascript\n${lastScript.code}\n\`\`\`\n\n[YÊU CẦU SỬA ĐỔI TỪ NGƯỜI DÙNG]:\n"${prompt}"\n\n[NGUYÊN TẮC BẮT BUỘC]:\n1. Sửa trực tiếp trên mã nguồn cũ, kế thừa 100% bố cục, màu sắc, font chữ, animation timeline và các hiệu ứng đã có.\n2. CHỈ thay đổi hoặc loại bỏ đúng các chi tiết mà người dùng yêu cầu (ví dụ: chỉ giữ lại avatar của người dùng, bỏ avatar khác).\n3. Trả về DUY NHẤT một JSON hợp lệ theo [CHẾ ĐỘ 1: INSPECT DATA & DYNAMIC TASKS] với trường "code" chứa hàm run({ client, guild, channel, user, message }), hàm run() luôn trả về trường 'reply' theo đúng phong cách Dolia.`;
            } else {
                promptInstruction = `${systemInstruction}\n\n[NHIỆM VỤ HIỆN TẠI]: Hãy thiết kế và lập trình script thực thi tác vụ dynamic / kiểm tra dữ liệu sau: "${prompt}".\nTrả về DUY NHẤT một JSON hợp lệ theo [CHẾ ĐỘ 1: INSPECT DATA & DYNAMIC TASKS] với trường "code" chứa hàm run({ client, guild, channel, user, message })!`;
            }
        } else {
            promptInstruction = `${systemInstruction}\n\n[NHIỆM VỤ HIỆN TẠI]: Hãy thiết kế và lập trình tính năng mới sau: "${prompt}". Tên lệnh được chỉ định: "${safeSlug}". Trả về DUY NHẤT một JSON hợp lệ theo [CHẾ ĐỘ 2: SLASH COMMAND]!`;
        }

        const sessionKey = context?.channel?.id ? `${context.guild?.id || 'dm'}_${context.channel.id}` : null;
        let dbSession = null;
        if (context?.user?.id && context?.channel?.id) {
            dbSession = await getAgentSession(context.user.id, context.channel.id);
        }

        return await antigravityKeyManager.execute(async (apiKey) => {
            const sessionEnv = antigravityKeyManager.getEnvironmentId(sessionKey) || dbSession;
            const skillSources = SkillHelper.getEnvironmentSources();

            let envParam = sessionEnv?.environmentId || "remote";
            let previousInteractionId = sessionEnv?.lastInteractionId || null;

            Logger.info(tr('logs.antigravityservice.info_antigravity_nap_session_kenh_environmentid_previousinteractionid', { value: context?.channel?.id || 'unknown', value2: sessionEnv?.environmentId || 'null (sẽ tạo mới remote container)', value3: previousInteractionId || 'null' }));

            if (!sessionEnv?.environmentId && skillSources.length > 0) {
                // Nhúng các file SKILL.md inline vào remote sandbox theo chuẩn Google Custom Agents
                envParam = {
                    type: "remote",
                    sources: skillSources
                };
                Logger.info(tr('logs.antigravityservice.info_antigravity_da_nhung_skills_vao_environment_sources', { length: skillSources.length, value: skillSources.map(s => s.target).join(', ') }));
            } else if (sessionEnv?.environmentId) {
                Logger.info(tr('logs.antigravityservice.info_antigravity_tai_su_dung_warm_sandbox_container', { environmentId: sessionEnv.environmentId, value: previousInteractionId ? ` (Chained Interaction: ${previousInteractionId})` : '' }));
            }

            const url = `https://generativelanguage.googleapis.com/v1beta/interactions?alt=sse&key=${apiKey}`;
            const requestPayload = {
                agent: "antigravity-preview-05-2026",
                input: promptInstruction,
                environment: envParam,
                stream: true,
                agent_config: {
                    type: "antigravity",
                    model: activeModel
                },
                system_instruction: systemInstruction
            };

            if (previousInteractionId) {
                requestPayload.previous_interaction_id = previousInteractionId;
            }

            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(requestPayload)
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                const err = Array.isArray(errorData) ? errorData[0]?.error : errorData.error;
                const apiErr = new Error(err?.message || `HTTP ${response.status} ${response.statusText}`);
                apiErr.status = response.status;
                apiErr.error = err;

                // Nếu môi trường cũ đã hết hạn hoặc không tìm thấy, xóa cache để lần sau tạo mới
                if (sessionEnv?.environmentId && (response.status === 400 || response.status === 404)) {
                    antigravityKeyManager.clearEnvironmentId(sessionKey);
                    if (context?.user?.id && context?.channel?.id) {
                        updateAgentSession(context.user.id, context.channel.id, {
                            environmentId: null,
                            lastInteractionId: null
                        }).catch(() => {});
                    }
                }

                throw apiErr;
            }

            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            let rawText = '';
            let finalInteraction = null;

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop();

                for (let i = 0; i < lines.length; i++) {
                    const line = lines[i].trim();
                    if (!line.startsWith('data:')) continue;
                    const jsonStr = line.replace(/^data:\s*/, '').trim();
                    if (!jsonStr) continue;

                    try {
                        const eventObj = JSON.parse(jsonStr);
                        const eventType = eventObj.event_type;

                        if (eventType === 'interaction.created' && eventObj.interaction) {
                            const newEnvId = eventObj.interaction.environment_id;
                            const newInteractionId = eventObj.interaction.id;
                            Logger.info(tr('logs.antigravityservice.info_antigravity_google_cloud_interaction_created_environmentid_interactionid', { value: newEnvId || 'null', value2: newInteractionId || 'null' }));
                            if (newEnvId) {
                                antigravityKeyManager.setEnvironmentId(newEnvId, sessionKey, newInteractionId);
                                if (context?.user?.id && context?.channel?.id) {
                                    updateAgentSession(context.user.id, context.channel.id, {
                                        environmentId: newEnvId,
                                        lastInteractionId: newInteractionId
                                    }).catch(() => {});
                                }
                            }
                            if (typeof onProgress === 'function') {
                                onProgress({ stage: 'connected', text: tr('messages.antigravityservice.text_dolia_da_ket_noi_khong_gian_dam'), event: eventType });
                            }
                        } else if (eventType === 'step.start') {
                            const stepType = eventObj.step?.type;
                            const stepName = eventObj.step?.name || '';
                            if (stepType === 'thought') {
                                if (typeof onProgress === 'function') {
                                    onProgress({ stage: 'thinking', text: tr('messages.antigravityservice.text_dolia_dang_phan_tich_va_thiet_ke'), event: eventType, stepType });
                                }
                            } else if (stepType === 'code_execution_call') {
                                if (typeof onProgress === 'function') {
                                    onProgress({ stage: 'coding', text: tr('messages.antigravityservice.text_dolia_dang_viet_ma_lenh_va_kiem'), event: eventType, stepType });
                                }
                            } else if (stepType === 'function_call') {
                                const toolLabel = stepName === 'write_file' ? tr('messages.antigravityservice.text_luu_file') : stepName === 'google_search' ? tr('messages.antigravityservice.text_tim_kiem_google') : stepName === 'url_context' ? tr('messages.antigravityservice.text_doc_tai_lieu') : tr('messages.antigravityservice.text_goi_cong_cu');
                                if (typeof onProgress === 'function') {
                                    onProgress({ stage: 'tool_call', text: tr('messages.antigravityservice.text_dolia_dang_tren_dam_may', { toolLabel: toolLabel }), event: eventType, stepType, toolName: stepName });
                                }
                            } else if (stepType === 'model_output') {
                                if (typeof onProgress === 'function') {
                                    onProgress({ stage: 'output', text: tr('messages.antigravityservice.text_gan_xong_roi_ne_minh_dang_dong'), event: eventType, stepType });
                                }
                            } else if (typeof onProgress === 'function') {
                                onProgress({ stage: 'step', text: tr('messages.antigravityservice.text_dolia_dang_xu_ly_buoc', { value: stepType || 'unknown' }), event: eventType, stepType });
                            }
                        } else if (eventType === 'step.end') {
                            const stepType = eventObj.step?.type;
                            if (stepType === 'code_execution_call') {
                                if (typeof onProgress === 'function') {
                                    onProgress({ stage: 'code_done', text: tr('messages.antigravityservice.text_ma_lenh_da_kiem_thu_xong_tren'), event: eventType, stepType });
                                }
                            }
                        } else if (eventType === 'step.delta') {
                            if (eventObj.delta?.text) {
                                rawText += eventObj.delta.text;
                            }
                        } else if (eventType === 'interaction.completed') {
                            finalInteraction = eventObj.interaction;
                            Logger.info(tr('logs.antigravityservice.info_antigravity_google_cloud_interaction_completed_environmentid_interactionid', { value: finalInteraction?.environment_id || 'null', value2: finalInteraction?.id || 'null' }));
                            if (finalInteraction?.environment_id) {
                                antigravityKeyManager.setEnvironmentId(finalInteraction.environment_id, sessionKey, finalInteraction.id);
                                if (context?.user?.id && context?.channel?.id) {
                                    updateAgentSession(context.user.id, context.channel.id, {
                                        environmentId: finalInteraction.environment_id,
                                        lastInteractionId: finalInteraction.id
                                    }).catch(() => {});
                                }
                            }
                            if (typeof onProgress === 'function') {
                                onProgress({ stage: 'completed', text: tr('messages.antigravityservice.text_antigravity_cloud_da_hoan_tat'), event: eventType });
                            }
                        } else if (eventType === 'interaction.failed') {
                            Logger.error(tr('logs.antigravityservice.error_antigravity_interaction_failed', { value: JSON.stringify(eventObj.error || eventObj) }));
                            if (typeof onProgress === 'function') {
                                onProgress({ stage: 'failed', text: tr('messages.antigravityservice.text_dam_may_gap_su_co'), event: eventType });
                            }
                        }
                    } catch (_) { }
                }
            }

            Logger.info(tr('logs.antigravityservice.info_antigravity_antigravity_cloud_stream_hoan_tat'));

            // Trích xuất output hoàn chỉnh từ finalInteraction nếu có
            if (finalInteraction && Array.isArray(finalInteraction.steps)) {
                const modelOutputStep = [...finalInteraction.steps].reverse().find(s => s.type === 'model_output');
                if (modelOutputStep?.content) {
                    const extracted = modelOutputStep.content.map(c => c.text || '').join('\n');
                    if (extracted.length > rawText.length) {
                        rawText = extracted;
                    }
                }
                if (!rawText) {
                    const writeStep = finalInteraction.steps.find(s => s.type === 'function_call' && s.name === 'write_file');
                    if (writeStep?.arguments?.content) {
                        rawText = writeStep.arguments.content;
                    }
                }
            }

            // Trích xuất JSON
            let parsedData = null;
            try {
                parsedData = JSON.parse(rawText);
            } catch (_) {
                const match = rawText.match(/```(?:json)?([\s\S]*?)```/);
                if (match) {
                    try { parsedData = JSON.parse(match[1].trim()); } catch (_) {}
                }
                if (!parsedData) {
                    const jsonMatch = rawText.match(/\{[\s\S]*\}/);
                    if (jsonMatch) {
                        try { parsedData = JSON.parse(jsonMatch[0].trim()); } catch (_) {}
                    }
                }
            }

            const currentEnvId = antigravityKeyManager.getEnvironmentId(sessionKey)?.environmentId || null;

            if (isScript) {
                let scriptCode = parsedData?.code || parsedData?.files?.[0]?.content || parsedData?.content || null;
                if (!scriptCode) {
                    const jsMatch = rawText.match(/```(?:javascript|js)\b\s*([\s\S]*?)\s*```/i);
                    if (jsMatch) {
                        scriptCode = jsMatch[1].trim();
                    } else {
                        const blockMatch = rawText.match(/```(?:[a-zA-Z0-9_-]+)?\s*([\s\S]*?)\s*```/);
                        const blockContent = blockMatch ? blockMatch[1].trim() : rawText.trim();
                        try {
                            const p = JSON.parse(blockContent);
                            scriptCode = p.code || p.content || null;
                        } catch (_) {
                            const jsonMatch = blockContent.match(/\{[\s\S]*\}/);
                            if (jsonMatch) {
                                try {
                                    const p = JSON.parse(jsonMatch[0].trim());
                                    scriptCode = p.code || p.content || null;
                                } catch (_) {}
                            }
                        }
                    }
                }

                if (!scriptCode) {
                    const matchCode = rawText.match(/"code"\s*:\s*"([\s\S]*?)"\s*(?:,\s*"|\}$)/);
                    if (matchCode) {
                        try {
                            scriptCode = JSON.parse(`"${matchCode[1]}"`).trim();
                        } catch (_) {
                            scriptCode = matchCode[1]
                                .replace(/\\n/g, '\n')
                                .replace(/\\"/g, '"')
                                .replace(/\\\\/g, '\\')
                                .trim();
                        }
                    }
                }

                if (scriptCode) {
                    scriptCode = scriptCode.replace(/^```(?:[a-zA-Z0-9_-]+)?\s*/i, '').replace(/\s*```$/i, '').trim();
                }

                // Kiểm tra an toàn: Tuyệt đối không để nguyên khối JSON ghi vào file .js
                if (scriptCode && (scriptCode.includes('"code"') || scriptCode.includes('"type"'))) {
                    const firstBrace = scriptCode.indexOf('{');
                    const lastBrace = scriptCode.lastIndexOf('}');
                    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
                        try {
                            const p = JSON.parse(scriptCode.substring(firstBrace, lastBrace + 1));
                            if (p.code) scriptCode = p.code.trim();
                        } catch (_) {
                            const matchCode = scriptCode.match(/"code"\s*:\s*"([\s\S]*?)"\s*(?:,\s*"|\}$)/);
                            if (matchCode) {
                                try {
                                    scriptCode = JSON.parse(`"${matchCode[1]}"`).trim();
                                } catch (_) {
                                    scriptCode = matchCode[1]
                                        .replace(/\\n/g, '\n')
                                        .replace(/\\"/g, '"')
                                        .replace(/\\\\/g, '\\')
                                        .trim();
                                }
                            }
                        }
                    }
                }

                if (!scriptCode || !scriptCode.includes('run(')) {
                    throw new Error("Mã nguồn script trả về từ Antigravity Agent không hợp lệ (thiếu hàm run).");
                }

                if (process.platform === 'win32') {
                    scriptCode = scriptCode.replace(/(['"`])python3\s+/g, '$1python ');
                    scriptCode = scriptCode.replace(/(\bexecSync\s*\(\s*['"`])python3\b/g, '$1python');
                    scriptCode = scriptCode.replace(/(\bexec\s*\(\s*['"`])python3\b/g, '$1python');
                    scriptCode = scriptCode.replace(/(\bspawn\s*\(\s*['"`])python3(['"`])/g, '$1python$2');
                }

                // Tự động sửa lỗi regex escape bị mất slash: replace(/\/g, '/') -> replaceAll('\\', '/')
                scriptCode = scriptCode.replace(/\.replace\(\/\\?\/g\s*,\s*(['"`])\/\1\)/g, ".replaceAll('\\\\', '/')");

                // Tự động sửa lỗi Agent lưu vào scriptPath nhưng execSync lại gọi tên file cộc lốc
                if (scriptCode.includes('scriptPath')) {
                    scriptCode = scriptCode.replace(
                        /execSync\s*\(\s*(['"`])(?:python3?|py)\s+([a-zA-Z0-9_-]+\.py)\1/g,
                        'execSync(`python "${scriptPath}"`'
                    );
                }

                return {
                    success: true,
                    mode: 'script',
                    scriptCode,
                    data: parsedData || { code: scriptCode },
                    usedModel: activeModel,
                    usedAgent: 'antigravity-preview-05-2026',
                    environmentId: currentEnvId
                };
            } else {
                if (!parsedData || !parsedData.files || !Array.isArray(parsedData.files) || parsedData.files.length === 0) {
                    throw new Error("Dữ liệu trả về từ Antigravity Agent không chứa cấu trúc files hợp lệ.");
                }

                return {
                    success: true,
                    mode: 'command',
                    data: parsedData,
                    usedModel: activeModel,
                    usedAgent: 'antigravity-preview-05-2026',
                    environmentId: currentEnvId
                };
            }
        }, { timeoutMs: 180000, maxRetries: 2 });
    }

    /**
     * Tạo tính năng Slash Command mới (Backward Compatible Alias)
     */
    static async developFeature(options) {
        return await this.develop({ ...options, mode: 'command' });
    }

    /**
     * Tạo hoặc chỉnh sửa Script tác vụ dynamic (Cloud Managed Sandbox)
     */
    static async developScript(options) {
        return await this.develop({ ...options, mode: 'script' });
    }
}

export default AntigravityService;

